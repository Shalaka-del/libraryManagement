from django.urls import path
from . import views

urlpatterns = [
    path("", views.base, name="base"),
    path("home", views.home, name="home"),
    path("home2", views.home2, name="home2"),
    path("memberLogin",views.memberLogin, name="memberLogin"),
    path("memberRegister", views.memberRegister, name="memberRegister"),
    path("memberLogout", views.memberLogout, name="memberLogout"),
]